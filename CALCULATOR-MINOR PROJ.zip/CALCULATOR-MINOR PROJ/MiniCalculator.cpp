/**************************************Minor Project**********************************
**************************************Calculator***************************************/
#include<iostream>
#include<math.h>
# define pi 3.141592654
using namespace std;

int alpha(char);
void fordelay(int j)     				//for delay funtion
{   int i,k;
    for(i=0;i<j;i++)
         k=i;
}
class calc{
	double x,y;
	char c;
public:
       double menu();                  //Mathematical operations menu

};

double calc::menu()
{
	 while(1)
	 {    	 	 		     
        int i=0; 	
      cout<<"\n\n***********************************************************************************************************************"<<endl;
      cout<<"\n\n                                                  CALCULATOR                                                  "<<endl;
      cout<<"\n\n***********************************************************************************************************************"<<endl<<endl;
      cout<<" MADE BY: AANCHAL";
      cout<<"\n MCA 2ND SEM(EVE)";
      cout<<"\n R.No. 51\n\n\n";
      system("\npause\n");cout<<"\n\n\n\t\t\t\t\t\tLOADING";
        for(i=0;i<=6;i++)
        {
            fordelay(150000000);
            cout<<".";
        }
                system("cls");
        system("Color 1b");
          ret:
         ret1: cout<<"\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2 WELCOME TO MAIN MENU \xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2"<<endl<<endl;
          cout<<"\n1.MATHEMATICAL OPERATIONS";
          cout<<"\n2.HIGH-LEVEL OPERTIONS";
          cout<<"\n3.EXIT\n";
          cout<<"\nEnter your choice from (1-3): ";
          cin>>c;
          cout<<"\n";
	      cout<<endl;
	      system("cls");
        switch(c)   //main switch
         {
           case '1'://perform mathematical operation
		     {
	              char z;
	              while(1)
				   {
	              ret2: cout<<"\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2 MATHEMATICAL OPERATIONS \xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2"<<endl;  
				     cout<<"\nPlease enter the type of operation (from a-l or A-L): "<<endl;
	                 cout<<"\na.ADDITION"<<"\nb.SUBTRACTION"<<"\nc.MULTIPLICATION"<<"\nd.DIVISON"<<"\ne.MODULUS";
					 cout<<"\nf.SQUARE ROOT"<<"\ng.LOG"<<"\nh.POWER"<<"\ni.QUADRATIC EQUATION"<<"\nj.CUBE ROOT";
					 cout<<"\nk.TRIGONOMETRIC OPERATIONS"<<"\nl.EXIT"<<endl;
	                 cout<<"\nYour Selection:";
	                 cin>>z;
	                 system("cls");
	                 z=alpha(z);
	             switch(z)   //arithmatic switch
	              {
	                 case 'a':   //addition 
		                     cout<<"\nYou selected Addition operation."<<endl;
		                     cout<<"\nEnter first number: ";
		                     cin>>x;
		                     while(cin.fail())
		                     {
		                     	cin.clear();
		                     	cin.ignore(INT_MAX,'\n');
		                     	cout<<"\nYou can only enter numbers.\n";
		                     	cout<<"\nEnter First number:";
		                     	cin>>x;
							 }
		                     
		                     cout<<"\nEnter Second number: ";
		                     cin>>y;
		                     while(cin.fail())
		                     {
		                     	cin.clear();
		                     	cin.ignore(INT_MAX,'\n');
		                     	cout<<"\nYou can only enter numbers.\n";
		                     	cout<<"\nEnter Second number:";
		                     	cin>>y;
							 }
		                     cout<<"\nSum="<<x+y<<endl;system("pause"); system("cls");
		             break;
		             
	                 case 'b': //subtraction
		                     cout<<"\nYou selected Subtraction Operation."<<endl;
		                     cout<<"\nEnter first number: ";
		                     cin>>x;
		                      while(cin.fail())
		                     {
		                     	cin.clear();
		                     	cin.ignore(INT_MAX,'\n');
		                     	cout<<"\nYou can only enter numbers.\n";
		                     	cout<<"\nEnter First number:";
		                     	cin>>x;
							 }
		                     
							 cout<<"\nEnter Second number: ";
							 cin>>y;
							 while(cin.fail())
		                     {
		                     	cin.clear();
		                     	cin.ignore(INT_MAX,'\n');
		                     	cout<<"\nYou can only enter numbers.\n";
		                     	cout<<"\nEnter Second number:";
		                     	cin>>y;
							 }

							 cout<<"\nSubtraction="<<x-y<<endl;system("pause");system("cls");
		             break;
	                 
					 case 'c': //multi
		                     cout<<"\nYou selected Multiplication operation."<<endl;
		                     cout<<"\nEnter first number: ";
		                     cin>>x;
		                      while(cin.fail())
		                     {
		                     	cin.clear();
		                     	cin.ignore(INT_MAX,'\n');
		                     	cout<<"\nYou can only enter numbers.\n";
		                     	cout<<"\nEnter First number:";
		                     	cin>>x;
							 }
		                     
							 cout<<"\nEnter Second number: ";
							 cin>>y;
							 while(cin.fail())
		                     {
		                     	cin.clear();
		                     	cin.ignore(INT_MAX,'\n');
		                     	cout<<"\nYou can only enter numbers.\n";
		                     	cout<<"\nEnter Second number:";
		                     	cin>>y;
							 }

							 cout<<"\nProduct="<<x*y<<endl;system("pause");system("cls");
		             break;
	                
					case 'd'://division
		                     cout<<"\nYou selected Division operation."<<endl;
		                     cout<<"\nEnter first number: ";
		                     cin>>x;
		                      while(cin.fail())
		                     {
		                     	cin.clear();
		                     	cin.ignore(INT_MAX,'\n');
		                     	cout<<"\nYou can only enter numbers.\n";
		                     	cout<<"\nEnter First number:";
		                     	cin>>x;
							 }		                     
		                     cout<<"\nEnter Second number: ";
		                     cin>>y;
		                     while(cin.fail())
		                     {
		                     	cin.clear();
		                     	cin.ignore(INT_MAX,'\n');
		                     	cout<<"\nYou can only enter numbers.\n";
		                     	cout<<"\nEnter Second number:";
		                     	cin>>y;
							 }
		                     try
		                     {
		                     	if(y==0)
		                     	  throw y;
		                     	  cout<<"\nDiv="<<x/y<<endl;
							 }
		                     catch(double y1)
		                     {
		                     	cout<<"\n Can't divide by:"<<y1<<endl;
							 }
							 system("pause");system("cls");
		             break;
		             
	                 case 'e'://mod
		                     cout<<"\nYou selected Modulus operation."<<endl;
		                     cout<<"\nEnter first number: ";
		                     cin>>x;
		                      while(cin.fail())
		                     {
		                     	cin.clear();
		                     	cin.ignore(INT_MAX,'\n');
		                     	cout<<"\nYou can only enter numbers.\n";
		                     	cout<<"\nEnter First number:";
		                     	cin>>x;
							 }
		                     
		                     cout<<"\nEnter Second number: ";
		                     cin>>y;
		                     while(cin.fail())
		                     {
		                     	cin.clear();
		                     	cin.ignore(INT_MAX,'\n');
		                     	cout<<"\nYou can only enter numbers.\n";
		                     	cout<<"\nEnter Second number:";
		                     	cin>>y;
							 }

		                     cout<<"\nMod="<<fmod(x,y)<<endl;system("pause");system("cls");
		             break;
		             
		             case 'f':   //Perform square root
		             	     cout<<"You choose square root function!"<<'\n';          
	                         cout<<"\nEnter a number:";
	                         cin>>x;
	                         while(cin.fail())
		                     {
		               	      cin.clear();
		               	      cin.ignore(INT_MAX,'\n');
		                      cout<<"\nYou can only enter numbers.\n";
		                      cout<<"\nEnter a number:";
		                      cin>>x;
					         }
	                        try
	                         { 
	                          if (x < 0.0)
                              throw "\nCan not take sqrt of negative number.\n";// throw exception of type const char*
	                          cout<<"Square Root="<<sqrt(x)<<endl;system("pause");system("cls");
	                         }
                             catch (const char* exception) // catch exceptions of type const char*
                             {  
                               cerr << "Error: " << exception << '\n';
                             }
                             system("pause");system("cls");
	                 break;
	                 case 'g':   //Perform Log function
	                 	     cout<<"You choose Logarithmic(Log) function!"<<'\n';         
	                         cout<<"\nEnter the number:";
	                         cin>>x;
	                         while(cin.fail())
		                     {
		                      cin.clear();
		                      cin.ignore(INT_MAX,'\n');
		                      cout<<"\nYou can only enter numbers.\n";
		                      cout<<"\nEnter a number:";
		                      cin>>x;
						     }
	                        try
	                         {
	                          if (x <= 0.0)
                              throw "\nCan not find log of Negative/Zero number!! Please try valid number."; 
	                          system("pause");system("cls");
	                         }
                            catch (const char* exception) // catch exceptions of type const char*
                            { 
                             cerr << "Error: " << exception << '\n';
                            }
                            system("pause");system("cls");
	                 break;
	                 case 'h':   //Perform Power function
     	                     cout<<"\nYou choose Power function!"<<'\n';                 
     	                     cout<<"\nEnter the base number:";
     	                     cin>>x;
     	                     while(cin.fail())
		                     {
		                      cin.clear();
		                      cin.ignore(INT_MAX,'\n');
		                      cout<<"\nYou can only enter numbers.\n";
		                      cout<<"\nEnter base number:";
		                      cin>>x;
						     }
				             cout<<"\nEnter the power:";
				             cin>>y;
				             while(cin.fail())
		                     {
		                      cin.clear();
		                      cin.ignore(INT_MAX,'\n');
		                      cout<<"\nYou can only enter numbers.\n";
		                      cout<<"\nEnter the power:";
		                      cin>>y;
						     }
				             cout<<x<<" to the power of "<<y<<": "<<pow(x,y)<<endl<<endl;system("pause"); system("cls");
				     break;
				     case 'i':  //Perform Quadratic equation
                             double z,x1,x2;
     	                     cout<<"\nYou choose Quadratic Equation!"<<'\n';                   
     	                     cout<<"\nEnter the value for x:";
     	                     cin>>x;
     	                     while(cin.fail())
		                     {
		                      cin.clear();
		                      cin.ignore(INT_MAX,'\n');
		                      cout<<"\nYou can only enter numbers.\n";
		                      cout<<"\nEnter the value for x:";
		                      cin>>x;
						     }
				             cout<<"\nEnter the value for y:";
     	                     cin>>y;
     	                     while(cin.fail())
		                     {
		                      cin.clear();
		                      cin.ignore(INT_MAX,'\n');
		                      cout<<"\nYou can only enter numbers.\n";
		                      cout<<"\nEnter the value for y:";
		                      cin>>y;
						     }
				             cout<<"\nEnter the value for z:";
     	                     cin>>z;
     	                     while(cin.fail())
		                     {
		                      cin.clear();
		                      cin.ignore(INT_MAX,'\n');
		                      cout<<"\nYou can only enter numbers.\n";
		                      cout<<"\nEnter the value for s:";
		                      cin>>z;
					         }
				             cout<<"\nx="<<x<<endl;
				             cout<<"\ny="<<y<<endl;
				             cout<<"\nz="<<z<<endl;
				             x1=(-y+sqrt((pow(y,2)-4*x*z)))/2*x;
				             x2=(-y-sqrt((pow(y,2)-4*x*z)))/2*x;
				             cout<<"\nFirst root is: "<<x1<<endl;
				             cout<<"\nSecond root is: "<<x2<<endl;system("pause"); system("cls");
				     break;
				     case 'k':  //Trigonometric functions
				               //Perform Trigonometric function
	 	             double x,y;
					  char z1;
	 	             while(1)
	 	             {
	 	               cout<<"You choose Trigonometric Function(in degree)!\n";          
	                   cout<<"Select the type from the following operations:\n\n1.Sin\n2.Cos\n3.Tan\n4.Cot(Tan Inverse)\n5.Exit\n";
		               cout<<"Your selection:";
		               cin>>z1;
		               system("cls");
		 
		            switch(z1) //Trigonometric switch
		            {
		  	        case '1':    //Perform sin operation
		  	          cout<<"\nYou choose Sin Operation!\n";
		  		      cout<<"\nSin ";
		  		      cin>>x;
		  		      y=(x/180)*pi;
		  		      cout<<"\nSin "<<x<<"="<<sin(y)<<endl;system("pause"); system("cls");
		  		      break;
		  		
			        case '2':  //Perform cos operation
			         cout<<"\nYou choose Cos Operation!\n";
		  		     cout<<"\nCos ";
		  		     cin>>x;
		  		     y=(x/180)*pi;
		  		     cout<<"\nCos "<<x<<"="<<cos(y)<<endl;system("pause"); system("cls");
		  		     break;
		  		 
			        case '3':  //Perform tan operation
			                cout<<"\nYou choose Tan Operation!\n";
		  		            cout<<"\nTan ";
		  		            cin>>x;
		  		            y=(x/180)*pi;
		  		          cout<<"\nTan "<<x<<"="<<tan(y)<<endl;system("pause"); system("cls");
		  		     break;
		  		     case '4':  //Perform tan inverse(cot) operation
			                cout<<"\nYou choose Tan Inverse(Cot) Operation!\n";
		  		            cout<<"\nCot ";
		  		            cin>>x;
		  		            y=(180/x)*pi;
		  		            cout<<"\nCot "<<x<<"="<<atan(y)<<endl;system("pause"); system("cls");
		  		     break;
		  		     case '5':
		  		     	goto ret2;
		  		     	 system("pause");system("cls");
			         default:
			 	     cout<<"Error!!Please select the correct type of trigonometric functions!\n\n";
				     system("pause");system("cls");
		           }  //Closing trigonometric switch
                  }  //Closing Trigonometric while

				     break;
					 case 'j':  //Perform Cube root
                    	     cout<<"You choose Cube root function!"<<'\n';          
	                         cout<<"\nEnter a number:";
	                         cin>>x;
	                         while(cin.fail())
		                     {
		                    	cin.clear();
		                   	    cin.ignore(INT_MAX,'\n');
		                        cout<<"\nYou can only enter numbers.\n";
		                   	    cout<<"\nEnter a number:";
		                   	     cin>>x;
						     }
						     y=cbrt(x);
						     cout<<"\nCube root="<<y<<endl;system("pause");system("cls");
					 break;       
	                 case 'l'://exit arithmatic operations
		                     goto ret;
		                     
	                 default:
		                     cout<<"Invalid choice!! Please enter another choice.\n";
		                     system("pause");system("cls");
	              }//close switch arithmatic
		           }
	       break;
	         } //Closing case 1
   	         
   	        case '2'://High level operations
   	                while(1)
   	                { 
   	                     char ch;
   	                     float temp,res;
   	                    t:cout<<"\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2HIGH LEVEL OPERATIONS\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2"<<endl;
   	                	cout<<"\n1.TEMPERATURE CONVERSION"<<"\n2.NUMBER SYSTEM CONVERSION"<<"\n3.EXIT"<<endl;
   	                	cout<<"\nEnter your choice(1-3): ";
   	                	cin>>ch;
   	                	system("cls");
   	                	ch=alpha(ch);
   	                	switch(ch)
   	                	{
   	                		case '1': //Temperature Conversion
   	                		   while(1)
   	                		   {
   	                		   	 char a;
   	                		   	 cout<<"\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2 TEMPERATURE CONVERSION \xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2"<<endl;
   	                		   	 cout<<"\na.FAHRENHEIT TO CELSIUS"<<"\nb.CELSIUS TO FAHRENHEIT"<<"\nc.EXIT";
   	                		   	  cout<<"\n Enter your Selection from (a-c or A-C):";
   	                		   	  cin>>a;
   	                		   	
   	                		   	  system("cls");
   	                		   	  a=alpha(a);
   	                		   	  switch(a)
   	                		   	  {
   	                		   	  	 case 'a'://Fahrenheit to Celsius
   	                		   	  	          cout<<"\nYou choose Fahrenheit to Celsius Conversions!!"<<endl;
   	                		   	  	          cout<<"\nEnter temperature in Fahrenheit(F)):";
   	                		   	  	          cin>>temp;
   	                		   	  	          res=(temp-32)/1.8;
   	                		   	  	          cout<<"\nConverted Temperature= "<<res<<"C"<<endl;system("pause");system("cls");
   	                		   	  	 break;
									 case 'b'://Celsius to Fahrenheit
									          cout<<"\nYou choose Celsius to Fahrenheit Conversion!!"<<endl;
									          cout<<"\nEnter temperature in Celcius(C):";
   	                		   	  	          cin>>temp;       
   	                		   	  	          res=(temp*1.8)+32;
   	                		   	  	          cout<<"\nConverted Temperature= "<<res<<"F"<<endl;system("pause");system("cls");
   	                		   	  	 break;
   	                		   	  	 case 'c'://goto Temp conversion menu
   	                		   	  	         goto t;
   	                		   	  	         system("pause");system("cls");
   	                		   	  	 break;
   	                		   	  	 default:
   	                		   	  	 	     cout<<"Invalid choice!! Please choose valid choice.";
   	                		   	  	 	     system("pause");system("cls");
								  }
							   }
						  break;
						  
						  case '2'://Number system conversion
						            while(1)
						            {
						         int b[10],i,n;     
   	                		   	 char a;
   	                		   	 p:cout<<"\n\n\t\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2 NUMBER SYSTEM CONVERSION \xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2"<<endl;
   	                		   	 cout<<"\na.DECIMAL TO BINARY"<<"\nb.DECIMAL TO OCTAL"<<"\nc.DECIMAL TO HEXADECIMAL"<<"\nd.EXIT";
   	                		   	  cout<<"\n Enter your Selection from (a-d or A-D):";
   	                		   	  cin>>a;
   	                		   	
   	                		   	  system("cls");
   	                		   	  a=alpha(a);
   	                		   	  switch(a)
   	                		   	  {
   	                		   	  	 case 'a'://Decimal to binary
   	                		   	  	           cout<<"\nYou choose Decimal to Binary Conversion"<<endl<<endl;
                                             cout<<"\nEnter the number in decimal:";
                                             cin>>n;
                                             for(i=0;n>0;i++)
                                             {
                                             	b[i]=n % 2;
                                             	n=n/2;
											 }
											 cout<<"\nBinary of the given number is:";
											 for(i=i-1;i>=0;i--)
											 {
											 	cout<<b[i];
											 }
											 cout<<endl;
											 system("pause");system("cls");
   	                		   	  	 break;
									  
									  case 'd'://to exit number switch
									         goto p;
   	                		   	  	         system("pause");system("cls");
   	                		   	  	 break;
   	                		   	  	 default:
   	                		   	  	 	     cout<<"Invalid choice!! Please choose valid choice.";
   	                		   	  	 	     system("pause");system("cls");

									}
						   }
						  break;
						  case '3'://goto High level menu
						            goto ret1;
									//system("pause");system("cls");
						  break;
						  default:
						  	      cout<<"Invalid choice!! Please choose valid choice.";
   	                		   	  	 	     system("pause");system("cls");
						  	   
						}
					}
   	        break;	
            case '3':
            	 cout<<"\n\n\t\tThanks for using Calculator....";
	             exit(0);
	             system("cls");
	            
	         break;
	        default:
        	     cout<<"Invalid Choice!! Please enter another choice.\n";system("pause");system("cls");
        break;
		 }
	 }
      //return 0;
}

int main()
{
     calc m;
    
         m.menu();
         return 0;
}

int alpha(char s)
{
	 if (isupper(s)) s=tolower(s);
	 {
	 	return s;
	 }
}

